* Kelly Lougheed <kelly@smdrugstore.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
  * Jairo Llopis
