* Go to **Project > Configuration > Project Types** and add some items in order to
  categorize projects and tasks as you want.
* Go to Project Dashboard and edit any project and enter its type.
* Now you can group projects by type.
* This is the same for tasks.
