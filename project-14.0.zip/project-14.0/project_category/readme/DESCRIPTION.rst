This module adds the category type fields in project and task.
