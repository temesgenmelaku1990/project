To use this module, you need to:

#. Go to a task;
#. click on 'Dependencies'.
