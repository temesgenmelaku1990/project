This module shows arrows between tasks and their dependencies (on the timeline view).

Like this:

.. image:: ../static/description/screenshot.png
    :alt: Screenshot
