This module allows stock request orders to be created and linked to projects and project tasks.
