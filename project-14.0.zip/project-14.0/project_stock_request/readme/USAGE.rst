To use this module, you need to:

* User must have stock request user permissions
* On either a project or project task, go to the service request orders tab
* Create the stock request order(s).
