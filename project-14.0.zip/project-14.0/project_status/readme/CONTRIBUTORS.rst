* Patrick Wilson <patrickraymondwilson@gmail.com>
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * João Marques
