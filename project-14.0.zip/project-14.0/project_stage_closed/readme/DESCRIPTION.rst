.. warning::

  This module is deprecated in version ``14.0``. All business logic has been removed
  to use the ``is_closed`` field from ``project`` module. This module only contains
  migration script.


  This module used to provides a 'closed' flag on project task stages.
