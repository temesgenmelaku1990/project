To use this module, you need to:

* Go to 'Project' > 'Projects' and select or create a new project;
* on the form view, enter a deadline (Expiration Date) and start date;
* the deadline is shown on the kanban and renders red when it's passed;
* both the start date and deadline are shown on the task form.
