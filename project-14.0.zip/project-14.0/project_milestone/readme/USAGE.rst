To use this module, you need to:

#. Have Manager rights for Project group to edit projects.
#. On the project form, set the "Use Milestones" option to enable milestones for the project.
#. Add the milestones to the project via the milestone tab on the project form.
#. Tasks will show a "Milestone" where you can set tasks into the proper milestone.
#. You also have the group by "Milestones" for task views.
