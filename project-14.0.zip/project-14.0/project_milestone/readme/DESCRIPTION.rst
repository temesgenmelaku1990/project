This module provides a project milestones on projects.
