This module allows maintaining project roster based on roles and assignments.
List of roles is configured at company level, while assignments can be created
on project, company, and cross-company levels, with configurable inheritance.
