To use this module, you need to:

#. Have Manager rights for Project group to create tags.
#. Go to the project form and add the necessary tags.
